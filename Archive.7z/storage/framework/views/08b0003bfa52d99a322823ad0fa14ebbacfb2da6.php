<?php $__env->startSection('title','Calendar'); ?>


<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/flag-icon/css/flag-icon.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/fullcalendar/js/main.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/fullcalendar/daygrid/main.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/fullcalendar/timegrid/main.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/fullcalendar/list/main.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/select2/select2.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/select2/select2-materialize.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/form-select2.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-calendar.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<!-- Full Calendar -->
<div id="app-calendar">
  <div class="calendar-filter">
    <div class="card-panel pt-1 pb-1">
      <div class="row">
        <form method="GET" action="<?php echo e(route('peserta.calendar')); ?>">
          <?php echo csrf_field(); ?>
            <div class="input-field col s12 m6 l4">
              <select id="delegasi" class="select2 browser-default" name="delegasi">
                    <option value="" selected>Delegasi</option>
                    <option value="HMTL">HMTL</option>
                    <option value="HMTI">HMTI</option>
                    <option value="HMM">HMM</option>
                    <option value="HME">HME</option>
                    <option value="HMTK">HMTK</option>
                    <option value="HIMASPAL">HIMASPAL</option>
                    <option value="HIMASKOM">HIMASKOM</option>
                    <option value="HMTG Magmadipa">HMTG Magmadipa</option>
                    <option value="HM Teknik Geodesi">HM Teknik Geodesi</option>
                    <option value="HMTP">HMTP</option>
                    <option value="HMS">HMS</option>
                    <option value="PSMT">PSMT</option>
                    <option value="Izzati">Izzati</option>
                    <option value="PMK">PMK</option>
                    <option value="PRMK">PRMK</option>
                    <option value="Momentum">Momentum</option>
                    <option value="FST">FST</option>
                    <option value="BEM FT">BEM FT</option>
                    <option value="SM FT">SM FT</option>
                    <option value="NON FT">NON FT</option>
              </select>
            </div>
            <div class="col s12 m6 l3 right">
              <div class="input-field col l10">
                
              </div>
              <div class="input-field col l2 pl-0">
                <button type="submit" name="action" class="btn-floating"><i class="material-icons">search</i></button>
              </div>
            </div>
        </form>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col s12">
      <div class="card mt-0">
        <div class="card-content">
          <h4 class="card-title">
            Peserta's Birthday
          </h4>
          <div id="basic-calendar"></div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/fullcalendar/lib/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/fullcalendar/js/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/fullcalendar/daygrid/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/fullcalendar/timegrid/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/fullcalendar/list/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/fullcalendar/interaction/main.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendors/select2/select2.full.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script type="text/javascript">
  var events = [
    <?php $__currentLoopData = $pesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    {
      'id' : <?php echo $event->id ?>,
      'title' : "<?php echo e($event->name); ?>'s Birthday",
      'start' : "<?php echo e($event->tanggal_lahir); ?>",
      'end' : ""
    },
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  ];
/* Calendar */
/*-------- */

$(document).ready(function () {

  $(".select2").select2({
    /* the following code is used to disable x-scrollbar when click in select input and
    take 100% width in responsive also */
    dropdownAutoWidth: true,
    width: '100%',
  });

  /* initialize the calendar
   -----------------------------------------------------------------*/
  var Calendar = FullCalendar.Calendar;

  //  Basic Calendar Initialize
  var basicCal = document.getElementById('basic-calendar');
  var fcCalendar = new FullCalendar.Calendar(basicCal, {
    header: {
      left: 'prev,next',
      center: 'title',
      right: 'listYear,listMonth'
    },
    views: {
      listMonth: {
        buttonText: 'list month'
      },
      listYear: {
        buttonText: 'list year'
      }
    },
    defaultView: 'listYear',
    defaultDate: '2001-01-01',
    editable: false,
    plugins: ["dayGrid", "interaction", "list"],
    eventLimit: true, // allow "more" link when too many events
    events: events,
  });
  fcCalendar.render();


})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/muthiakanianastiti/Documents/Projects/Website/baseft/resources/views/peserta/calendar.blade.php ENDPATH**/ ?>