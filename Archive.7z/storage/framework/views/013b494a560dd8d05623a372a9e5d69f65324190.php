<!-- BEGIN: Footer-->
<footer
  class="<?php echo e($configData['mainFooterClass']); ?> <?php if($configData['isFooterFixed']=== true): ?><?php echo e('footer-fixed'); ?><?php else: ?> <?php echo e('footer-static'); ?> <?php endif; ?> <?php if($configData['isFooterDark']=== true): ?> <?php echo e('footer-dark'); ?> <?php elseif($configData['isFooterDark']=== false): ?> <?php echo e('footer-light'); ?> <?php else: ?> <?php echo e($configData['mainFooterColor']); ?> <?php endif; ?>">
  <div class="footer-copyright">
    <div class="container">
      <span>&copy; 2020 <a href="https://github.com/soffandluffy"
          target="_blank">Sab</a>
      </span>
      <span class="right hide-on-small-only">
        Design and Developed by <a href="https://github.com/soffandluffy">Sab</a>
      </span>
    </div>
  </div>
</footer>

<!-- END: Footer--><?php /**PATH /Users/muthiakanianastiti/Documents/Projects/Website/baseft/resources/views/panels/footer.blade.php ENDPATH**/ ?>