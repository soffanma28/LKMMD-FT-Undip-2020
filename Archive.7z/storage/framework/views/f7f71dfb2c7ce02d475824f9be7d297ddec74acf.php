<?php $__env->startSection('title','Detail'); ?>


<?php $__env->startSection('vendor-style'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="section">
  <div class="card-panel">
    <div class="row">
      <div class="col s12 m7">
        <div class="display-flex media">
          <a href="#" class="avatar">
            <img src="<?php echo e(asset('images/peserta/'.$peserta->imageurl)); ?>" alt="users view avatar" class="z-depth-4 circle"
              height="128" width="128">
          </a>
          <div class="media-body ml-4">
            <h4 class="media-heading">
              <span class="users-view-name"><?php echo e($peserta->name); ?></span>
              <?php if($peserta->jenis_kelamin == "Laki - Laki"): ?>
              <i class="fas fa-mars" style="color: #2196f3"></i>
              <?php else: ?> 
              <i class="fas fa-venus" style="color: #f06292"></i>
              <?php endif; ?>
            </h4>
            <h5 class="users-view-id"><?php echo e($peserta->delegasi); ?></h5>
          </div>
        </div>
      </div>
      <div class="col s12 m5 quick-action-btns display-flex justify-content-end align-items-center pt-2">
        <a href="#" class="btn-small btn-light-indigo"><i
            class="material-icons">mail_outline</i></a>
      </div>
    </div>
  </div>

  <!-- users view card details start -->
  <div class="card">
    <div class="card-content">
      <div class="row">
        <div class="col l6">
          <h6 class="mb-2 mt-2"><i class="material-icons">error_outline</i> Personal Info</h6>
          <table class="striped">
            <tbody>
              <tr>
                <td>Birthday :</td>
                <td><?php echo e($peserta->tempat_lahir); ?>, <?php echo e($peserta->tanggal_lahir->format('d F Y')); ?></td>
              </tr>
              <tr>
                <td>Jurusan :</td>
                <td><?php echo e($peserta->jurusan); ?></td>
              </tr>
              <tr>
                <td>Panggilan :</td>
                <td><?php echo e($peserta->panggilan); ?></td>
              </tr>
              <tr>
                <td>Agama :</td>
                <td><?php echo e($peserta->agama); ?></td>
              </tr>
              <tr>
                <td>Asal :</td>
                <td><?php echo e($peserta->asal); ?></td>
              </tr>
              <tr>
                <td>Hobi :</td>
                <td><?php echo e($peserta->hobi); ?></td>
              </tr>
              <tr>
                <td>Motto :</td>
                <td><?php echo e($peserta->motto); ?></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="col l6">
          <h6 class="mb-2 mt-2"><i class="material-icons">link</i> Social Links</h6>
          <table class="striped">
            <tbody>
              <tr>
                <td>Line :</td>
                <td><a href="https://www.line.me/ti/p/<?php echo e($peserta->line); ?>"><?php echo e($peserta->line); ?></a></td>
              </tr>
              <tr>
                <td>Instagram :</td>
                <td><a href="https://www.instagram.com/<?php echo e($peserta->instagram); ?>"><?php echo e($peserta->instagram); ?></a></td>
              </tr>
              <tr>
                <td>Twitter :</td>
                <td><a href="https://www.twitter.com/<?php echo e($peserta->twitter); ?>"><?php echo e($peserta->twitter); ?></a></td>
              </tr>
              <tr>
                <td>Github :</td>
                <td><a href="https://www.github.com/<?php echo e($peserta->github); ?>"><?php echo e($peserta->github); ?></a></td>
              </tr>
              <tr>
                <td>LinkedIn :</td>
                <td><a href="https://www.linkedin.com/<?php echo e($peserta->github); ?>"><?php echo e($peserta->linkedin); ?></a></td>
              </tr>
              <tr>
                <td>Whatsapp :</td>
                <?php $whatsapp = ltrim($peserta->whatsapp, '0'); ?>
                <td><a href="https://www.wa.me/62<?php echo e($whatsapp); ?>"><?php echo e($peserta->whatsapp); ?></a></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <!-- </div> -->
    </div>
  </div>
  <!-- users view card details ends -->

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/muthiakanianastiti/Documents/Projects/Website/baseft/resources/views/peserta/view.blade.php ENDPATH**/ ?>