<?php $__env->startSection('title','Blank Page'); ?>


<?php $__env->startSection('content'); ?>
<div class="section">
    <div class="card">
        <div class="card-content">
            <p class="caption mb-0">
                Sample blank page for getting start!! Created and designed by Google, Material Design is a design
                language that combines the classic principles of successful design along with innovation and
                technology.
            </p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/muthiakanianastiti/Documents/Projects/Website/baseft/resources/views/pages/page-blank.blade.php ENDPATH**/ ?>