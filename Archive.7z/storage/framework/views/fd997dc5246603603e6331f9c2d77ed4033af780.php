<!-- BEGIN VENDOR JS-->
<script src="<?php echo e(asset('js/vendors.min.js')); ?>"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<script src="<?php echo e(asset('vendors/formatter/jquery.formatter.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/croppie/js/croppie.min.js')); ?>"></script>
<?php echo $__env->yieldContent('vendor-script'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- END PAGE VENDOR JS-->
<!-- BEGIN THEME  JS-->
<script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('js/search.js')); ?>"></script> -->
<script src="<?php echo e(asset('js/custom/custom-script.js')); ?>"></script>
<!-- END THEME  JS-->
<!-- BEGIN PAGE LEVEL JS-->
<?php echo $__env->yieldContent('page-script'); ?><?php /**PATH /Users/muthiakanianastiti/Documents/Projects/Website/baseft/resources/views/panels/scripts.blade.php ENDPATH**/ ?>