<?php $__env->startSection('title','Manage Peserta'); ?>


<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/jquery.dataTables.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/extensions/responsive/css/responsive.dataTables.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/select2/select2.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/select2/select2-materialize.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/form-select2.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/datatable.css')); ?>"> 
<style type="text/css">
  .btnAction {
    padding-left: 10%;
    padding-right: 10%;
  }
  .btnActionForm {
    padding-left: 26%;
    padding-right: 26%;
  }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row datatable-wrapper">
  <!-- <div class="col s12 m12 l12">
    <div class="card-panel">
      <div class="row">
        <form>
          <div class="col s12 m6 l3">
            <label for="users-list-verified">Verified</label>
            <div class="input-field">
              <select class="select2 browser-default" name="delegasi">
                  <option value="" selected>Delegasi</option>
                  <option value="HMTL">HMTL</option>
                  <option value="HMTI">HMTI</option>
                  <option value="HMM">HMM</option>
                  <option value="HME">HME</option>
                  <option value="HMTK">HMTK</option>
                  <option value="HIMASPAL">HIMASPAL</option>
                  <option value="HIMASKOM">HIMASKOM</option>
                  <option value="HMTG Magmadipa">HMTG Magmadipa</option>
                  <option value="HM Teknik Geodesi">HM Teknik Geodesi</option>
                  <option value="HMTP">HMTP</option>
                  <option value="HMS">HMS</option>
                  <option value="PSMT">PSMT</option>
                  <option value="Izzati">Izzati</option>
                  <option value="PMK">PMK</option>
                  <option value="PRMK">PRMK</option>
                  <option value="Momentum">Momentum</option>
                  <option value="FST">FST</option>
                  <option value="BEM FT">BEM FT</option>
                  <option value="SM FT">SM FT</option>
                  <option value="NON FT">NON FT</option>
              </select>
            </div>
          </div>
          <div class="col s12 m6 l3">
            <label for="users-list-role">Role</label>
            <div class="input-field">
              <select class="select2 browser-default" name="delegasi">
                  <option value="" selected>Delegasi</option>
                  <option value="HMTL">HMTL</option>
                  <option value="HMTI">HMTI</option>
                  <option value="HMM">HMM</option>
                  <option value="HME">HME</option>
                  <option value="HMTK">HMTK</option>
                  <option value="HIMASPAL">HIMASPAL</option>
                  <option value="HIMASKOM">HIMASKOM</option>
                  <option value="HMTG Magmadipa">HMTG Magmadipa</option>
                  <option value="HM Teknik Geodesi">HM Teknik Geodesi</option>
                  <option value="HMTP">HMTP</option>
                  <option value="HMS">HMS</option>
                  <option value="PSMT">PSMT</option>
                  <option value="Izzati">Izzati</option>
                  <option value="PMK">PMK</option>
                  <option value="PRMK">PRMK</option>
                  <option value="Momentum">Momentum</option>
                  <option value="FST">FST</option>
                  <option value="BEM FT">BEM FT</option>
                  <option value="SM FT">SM FT</option>
                  <option value="NON FT">NON FT</option>
              </select>
            </div>
          </div>
          <div class="col s12 m6 l3">
            <label for="users-list-status">Status</label>
            <div class="input-field">
              <select class="select2 browser-default" name="delegasi">
                  <option value="" selected>Delegasi</option>
                  <option value="HMTL">HMTL</option>
                  <option value="HMTI">HMTI</option>
                  <option value="HMM">HMM</option>
                  <option value="HME">HME</option>
                  <option value="HMTK">HMTK</option>
                  <option value="HIMASPAL">HIMASPAL</option>
                  <option value="HIMASKOM">HIMASKOM</option>
                  <option value="HMTG Magmadipa">HMTG Magmadipa</option>
                  <option value="HM Teknik Geodesi">HM Teknik Geodesi</option>
                  <option value="HMTP">HMTP</option>
                  <option value="HMS">HMS</option>
                  <option value="PSMT">PSMT</option>
                  <option value="Izzati">Izzati</option>
                  <option value="PMK">PMK</option>
                  <option value="PRMK">PRMK</option>
                  <option value="Momentum">Momentum</option>
                  <option value="FST">FST</option>
                  <option value="BEM FT">BEM FT</option>
                  <option value="SM FT">SM FT</option>
                  <option value="NON FT">NON FT</option>
              </select>
            </div>
          </div>
          <div class="col s12 m6 l3 display-flex align-items-center show-btn">

          </div>
        </form>
      </div>
    </div>
  </div> -->
  <div class="col s12 m12 l12 datatable-table">
      <div class="section">
        <div class="card border-radius-6">
          <div class="card-content">
            <div class="row">
              <div class="col s12 m12 l12">
                <div style="bottom: 60px; right: 20px;" class="fixed-action-btn direction-top">
                  <a class="btn-floating btn-large gradient-45deg-purple-deep-purple gradient-shadow modal-trigger" href="<?php echo e(route('peserta.add')); ?>"><i class="material-icons">add</i></a>
                </div>
              </div>
              <div class="col s12 m12 l12 pl-0 pr-0">
                <div class="col s12 m12 l12 responsive-table pl-0 pr-0">
                  <table id="peserta-datatable" class="table highlight">
                    <thead>
                      <tr>
                        <th>Avatar</th>
                        <th>Nama</th>
                        <th>Delegasi</th>
                        <th>Asal</th>
                        <th>TTL</th>
                        <th>Hobi</th>
                        <th>Instagram</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $pesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                          <td><img class="materialboxed" src="<?php echo e(asset('images/peserta/' . $peserta->imageurl . '')); ?>" width="96" height="96"></td>
                          <td><?php echo e($peserta->name); ?></td>
                          <td><?php echo e($peserta->delegasi); ?></td>
                          <td><?php echo e($peserta->asal); ?></td>
                          <td><?php echo e($peserta->tempat_lahir); ?>, <?php echo e($peserta->tanggal_lahir->format('d M Y')); ?></td>
                          <td><?php echo e($peserta->hobi); ?></td>
                          <td><?php echo e($peserta->instagram); ?></td>
                          <td style="width: 170px;">
                            <a href="<?php echo e(route('peserta.edit', $peserta->id)); ?>" class="btn amber lighten-1 btnAction waves-effect waves-dark tooltipped" data-position="bottom" data-tooltip="Edit"><i class="material-icons">edit</i></a>
                            <a href="#delete<?php echo e($peserta->id); ?>" class="btn red darken-2 btnAction waves-effect waves-dark modal-trigger tooltipped" data-position="bottom" data-tooltip="Delete"><i class="material-icons">delete</i></a>
  <!-- START Modal Delete Confirmation -->
  <div class="modal border-radius-6 width-30 pb-2" id="delete<?php echo e($peserta->id); ?>">
      <div class="modal-content">
        <div class="col s12 m12 l12">
          <h5>Are you sure?</h5>
          <form method="POST" action="<?php echo e(route('peserta.delete', $peserta->id)); ?>" class="right pt-4">
            <?php echo csrf_field(); ?>
            <a href="#!" class="btn grey lighten-2 modal-action modal-close waves-effect waves-dark" style="color: #555">Cancel
            </a>
            <button type="submit" class="btn deep-purple accent-2 waves-effect waves-light">Yes, Delete</button>
          </form>
        </div>
      </div>
  </div>
  <!-- END Modal Delete Confirmation -->
                            <a href="<?php echo e(route('peserta.view', $peserta->id)); ?>" class="btn btnAction waves-effect waves-dark tooltipped" data-position="bottom" data-tooltip="view"><i class="material-icons">remove_red_eye</i></a></a>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                        <td></td>
                        <td></td>
                        <td colspan="4" class="center">Data Empty</td>
                        <td></td>
                        <td></td>
                      </tr>
                      <?php endif; ?>
                    </tbody>
                </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/data-tables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/data-tables/extensions/responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendors/select2/select2.full.min.js')); ?>"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.js"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script type="text/javascript">

  var dat = [];

  $(document).ready(function(){
    $(".select2").select2({
        /* the following code is used to disable x-scrollbar when click in select input and
        take 100% width in responsive also */
        dropdownAutoWidth: true,
        width: '100%',
    });
    $('.modal').modal();
    $('.materialboxed').materialbox();

    $("#peserta-datatable").DataTable({
        // responsive: true,
        'initComplete': function(){
           var api = this.api();

           // Populate a dataset for autocomplete functionality
           // using data from first, second and third columns
           api.cells('tr', [1, 2, 3]).every(function(){
              // Get cell data as plain text   
              var d = this.data();
              if(dat.indexOf(d) === -1){ dat[d] = null; }
           });
           
           // Sort dataset alphabetically
           dat.sort();

           $('.dataTables_filter', api.table().container()).addClass('mr-2');
           $('.dataTables_filter input[type="search"] ', api.table().container()).wrap("<div class='input-field'></div>");
           $('.dataTables_filter input[type="search"] ', api.table().container()).addClass('autocomplete');
           $('.dataTables_filter input[type="search"]', api.table().container())
              .autocomplete({
                 data: dat,
              }
           );
        }
    });

  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/muthiakanianastiti/Documents/Projects/Website/baseft/resources/views/peserta/index.blade.php ENDPATH**/ ?>