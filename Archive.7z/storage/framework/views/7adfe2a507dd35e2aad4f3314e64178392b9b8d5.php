<?php $__env->startSection('title','Page Collapse'); ?>


<?php $__env->startSection('content'); ?>
<div class="section">
  <div class="card">
    <div class="card-content">
      <p class="caption mb-0">
        Sample blank page for getting start with default menu collapse! It use menu collapse class in body for
        collapse
        menu.
        Created and designed by Google, Material Design is a design
        language that combines the classic principles of successful design along with innovation and
        technology.
      </p>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vrushank/Downloads/materialize-admin-template-7.1/laravel-version/starter-kit/resources/views/pages/page-collapse.blade.php ENDPATH**/ ?>